package mundo;

import java.util.Random;

public class Logica {

    private final int[][] tablero;
    private int fila16;
    private int columna16;
    private final Random random;
    private int numeroMovs;

    public Logica() {
        random = new Random();
        tablero = new int[4][4];
        llenarTablero();
        buscarA16();
    }

    private void llenarTablero() {
        int contador = 1;
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 4; columna++) {
                tablero[fila][columna] = contador++;
            }
        }
        tablero[3][3] = 0; // La ficha 16 se representa con un 0
    }

    private void buscarA16() {
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 4; columna++) {
                if (tablero[fila][columna] == 0) {
                    fila16 = fila;
                    columna16 = columna;
                    return;
                }
            }
        }
    }

    public void intercambiarConVecino(int filaIngresada, int columnaIngresada) {
        if (esValida(filaIngresada, columnaIngresada)) {
            // Movimiento horizontal
            if (filaIngresada == fila16) {
                int deltaColumna = columnaIngresada - columna16;
                int paso = deltaColumna / Math.abs(deltaColumna); // Determina la dirección del movimiento
                for (int c = columna16; c != columnaIngresada; c += paso) {
                    intercambiar(fila16, c, fila16, c + paso);
                }
            } // Movimiento vertical
            else if (columnaIngresada == columna16) {
                int deltaFila = filaIngresada - fila16;
                int paso = deltaFila / Math.abs(deltaFila); // Determina la dirección del movimiento
                for (int f = fila16; f != filaIngresada; f += paso) {
                    intercambiar(f, columna16, f + paso, columna16);
                }
            } else {
                System.out.println("Movimiento no válido.");
            }
        } else {
            System.out.println("Posición ingresada no válida.");
        }
    }

    private boolean esValida(int fila, int columna) {
        return (Math.abs(fila - fila16) <= 3 && columna == columna16)
                || (Math.abs(columna - columna16) <= 3 && fila == fila16);
    }

    private void intercambiar(int fila1, int columna1, int fila2, int columna2) {
        int temp = tablero[fila1][columna1];
        tablero[fila1][columna1] = tablero[fila2][columna2];
        tablero[fila2][columna2] = temp;
        
        this.numeroMovs += 1;
        // Actualizar las coordenadas de la ficha blanca si se intercambió con ella
        if (temp == 0) {
            fila16 = fila2;
            columna16 = columna2;
        } else if (tablero[fila1][columna1] == 0) {
            fila16 = fila1;
            columna16 = columna1;
        }
    }

    public void mover16Aleatoriamente(int numeroDesorden) {
        
        for (int i = 0; i < numeroDesorden; i++) {
            int direccion = random.nextInt(4);
            int nuevaFila = fila16;
            int nuevaColumna = columna16;

            switch (direccion) {
                case 0:
                    nuevaFila--;
                    break;
                case 1:
                    nuevaFila++;
                    break;
                case 2:
                    nuevaColumna--;
                    break;
                case 3:
                    nuevaColumna++;
                    break;
            }

            if (nuevaFila >= 0 && nuevaFila < 4 && nuevaColumna >= 0 && nuevaColumna < 4) {
                intercambiar(nuevaFila, nuevaColumna, fila16, columna16);
            }
        }
        this.numeroMovs = 0;
    }

    public int getTablero(int fila, int columna) {
        return tablero[fila][columna];
    }

    public boolean esVictoria() {
        int contador = 1;
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 4; columna++) {
                if (tablero[fila][columna] != contador % 16) {
                    return false;
                }
                contador++;
            }
        }
        return true;
    }

    public int numeroMovimientos() {
        return this.numeroMovs;
    }
}
