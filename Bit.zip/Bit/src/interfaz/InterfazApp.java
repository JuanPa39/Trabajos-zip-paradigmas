package interfaz;

import java.util.Scanner;

public class InterfazApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Bit bit = new Bit();
        
         bit.setN(sc.nextInt());
        for (int i = 0; i <= bit.getN(); i++) {
            bit.ejecutarStatements(sc.nextLine());
        }
        System.out.println(bit.getX());
        
    }
    
}
class Bit {

    private int x, n;

    public Bit() {
        this.x = 0;
    }

    public int getX() {
        return x;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        if (n >= 1 && n <= 150) {
            this.n = n;
        }
    }

    public void ejecutarStatements(String operador) {
        if ("x++".equals(operador) || "++x".equals(operador)) {
            x += 1;
        } else if ("x--".equals(operador) || "--x".equals(operador)) {
            x -= 1;
        }
    }
}
