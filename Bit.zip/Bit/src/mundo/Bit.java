package mundo;

public class Bit {

    private int x, n;

    public Bit() {
        this.x = 0;
    }

    public int getX() {
        return x;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        if (n >= 1 && n <= 150) {
            this.n = n;
        }
    }

    public void ejecutarStatements(String operador) {
        if ("x++".equals(operador) || "++x".equals(operador)) {
            x += 1;
        } else if ("x--".equals(operador) || "--x".equals(operador)) {
            x -= 1;
        }
    }
}
