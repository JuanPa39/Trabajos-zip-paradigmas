/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import interfaz.PanelOperadores;
import interfaz.PanelOperandos;
import interfaz.PanelResultado;
import mundo.Dividir;

/**
 *
 * @author SG701-03
 */
public class Controlador {
    private Dividir dividir;
    private PanelOperandos pnlOperandos;
    private PanelOperadores pnlOperadores;
    private PanelResultado pnlResultado;

    public Controlador() {
       Dividir dividir = new Dividir();

    }

    public void conectar(PanelOperandos pnlOperandos, PanelOperadores pnlOperadores, PanelResultado pnlResultado) {
        this.pnlOperandos = pnlOperandos;
        this.pnlOperadores = pnlOperadores;
        this.pnlResultado = pnlResultado;
    }

}
