/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfaz;

import controlador.Controlador;

/**
 *
 * @author SG701-03
 */
public class InterfazApp 
{
    private Controlador ctrl;
    PanelResultado pnlResultado;
    PanelOperadores pnlOperadores;
    PanelOperandos pnlOperandos;

    public InterfazApp(Controlador ctrl) {
        this.ctrl = ctrl;
        this.pnlOperandos = new PanelOperandos();
        this.pnlOperadores = new PanelOperadores();
        this.pnlResultado = new PanelResultado();

    }

    public static void main(String[] args) {
        Controlador ctrl = new Controlador();
        InterfazApp interfazApp = new InterfazApp(ctrl);
    }

}

