package interfaz;

import controlador.Controlador;

public class PanelResultado {
    private Controlador crtl;
    
}
