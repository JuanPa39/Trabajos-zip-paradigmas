package interfaz;

import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagLayout;
import java.awt.Color;
import controlador.Controlador;
import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class PanelDatos extends JPanel {

    private Controlador controlador;
    private JTextArea textField = new JTextArea();

    public PanelDatos(Controlador controlador) {
        this.controlador = controlador;

        JPanel pnlDatos = new JPanel();
        pnlDatos.setLayout(new GridBagLayout());
        pnlDatos.setBackground(new Color(220, 220, 220));

        JButton boton = new JButton("Ejecutar");
        boton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = JOptionPane.showInputDialog("Introduce el número de términos:");
                int n = Integer.parseInt(input);
                String serie = controlador.generarSerie(n);
                textField.setText(serie);
            }
        });

        JPanel panel = new JPanel();
        panel.add(textField);
        panel.add(boton);
        add(panel, BorderLayout.CENTER);

    }

}
