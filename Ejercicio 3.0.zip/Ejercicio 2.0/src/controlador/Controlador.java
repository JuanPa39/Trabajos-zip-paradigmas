package controlador;

import interfaz.PanelDatos;
import mundo.Proceso;

public class Controlador {

    private Proceso proceso;
    private PanelDatos pnlDatos;

    public Controlador() {
        this.proceso = new Proceso();
    }

    public String generarSerie(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(Proceso.fibonacci(i)).append(" ");
        }
        return sb.toString();
    }

    public void setProceso(Proceso proceso) {
        this.proceso = proceso;
    }

}
