package banco;

import cuentas.Cuenta;
import cuentas.CuentaAhorro;
import cuentas.CuentaCorriente;
import cuentas.CuentaPlazoFijo;

import java.util.HashMap;
import java.util.Map;

public class Banco {
    private Map<String, Cuenta> cuentas;

    public Banco() {
        this.cuentas = new HashMap<>();
    }

    public void crearCuentaAhorro(String numeroCuenta, double saldoInicial) {
        cuentas.put(numeroCuenta, new CuentaAhorro(numeroCuenta, saldoInicial));
    }

    public void crearCuentaCorriente(String numeroCuenta, double saldoInicial, double limiteDescubierto) {
        cuentas.put(numeroCuenta, new CuentaCorriente(numeroCuenta, saldoInicial, limiteDescubierto));
    }

    public void crearCuentaPlazoFijo(String numeroCuenta, double saldoInicial, int plazo, double interes) {
        cuentas.put(numeroCuenta, new CuentaPlazoFijo(numeroCuenta, saldoInicial, plazo, interes));
    }

    public Cuenta obtenerCuenta(String numeroCuenta) {
        return cuentas.get(numeroCuenta);
    }

    public void realizarDeposito(String numeroCuenta, double cantidad) {
        Cuenta cuenta = cuentas.get(numeroCuenta);
        if (cuenta != null) {
            cuenta.depositar(cantidad);
        } else {
            System.out.println("Cuenta no encontrada.");
        }
    }

    public void realizarRetiro(String numeroCuenta, double cantidad) {
        Cuenta cuenta = cuentas.get(numeroCuenta);
        if (cuenta != null) {
            cuenta.retirar(cantidad);
        } else {
            System.out.println("Cuenta no encontrada.");
        }
    }

    public void realizarTransferencia(String numeroCuentaOrigen, String numeroCuentaDestino, double cantidad) {
        Cuenta cuentaOrigen = cuentas.get(numeroCuentaOrigen);
        Cuenta cuentaDestino = cuentas.get(numeroCuentaDestino);
        if (cuentaOrigen != null && cuentaDestino != null) {
            cuentaOrigen.transferir(cuentaDestino, cantidad);
        } else {
            System.out.println("Cuenta de origen o destino no encontrada.");
        }
    }
}

