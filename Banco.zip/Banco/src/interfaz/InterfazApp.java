package interfaz;

import controlador.Controlador;

import java.util.Scanner;

public class InterfazApp {
    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenido al Banco");

        while (true) {
            System.out.println("\nOpciones:");
            System.out.println("1. Crear cuenta de ahorro");
            System.out.println("2. Crear cuenta corriente");
            System.out.println("3. Crear cuenta a plazo fijo");
            System.out.println("4. Depositar");
            System.out.println("5. Retirar");
            System.out.println("6. Transferir");
            System.out.println("7. Consultar saldo");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuentaAhorro = scanner.next();
                    System.out.print("Ingrese el saldo inicial: ");
                    double saldoInicialAhorro = scanner.nextDouble();
                    controlador.crearCuentaAhorro(numeroCuentaAhorro, saldoInicialAhorro);
                    break;
                case 2:
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuentaCorriente = scanner.next();
                    System.out.print("Ingrese el saldo inicial: ");
                    double saldoInicialCorriente = scanner.nextDouble();
                    System.out.print("Ingrese el límite de descubierto: ");
                    double limiteDescubierto = scanner.nextDouble();
                    controlador.crearCuentaCorriente(numeroCuentaCorriente, saldoInicialCorriente, limiteDescubierto);
                    break;
                case 3:
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuentaPlazoFijo = scanner.next();
                    System.out.print("Ingrese el saldo inicial: ");
                    double saldoInicialPlazoFijo = scanner.nextDouble();
                    System.out.print("Ingrese el plazo en meses: ");
                    int plazo = scanner.nextInt();
                    System.out.print("Ingrese el interés anual: ");
                    double interes = scanner.nextDouble();
                    controlador.crearCuentaPlazoFijo(numeroCuentaPlazoFijo, saldoInicialPlazoFijo, plazo, interes);
                    break;
                case 4:
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuentaDeposito = scanner.next();
                    System.out.print("Ingrese la cantidad a depositar: ");
                    double cantidadDeposito = scanner.nextDouble();
                    controlador.realizarDeposito(numeroCuentaDeposito, cantidadDeposito);
                    break;
                case 5:
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuentaRetiro = scanner.next();
                    System.out.print("Ingrese la cantidad a retirar: ");
                    double cantidadRetiro = scanner.nextDouble();
                    controlador.realizarRetiro(numeroCuentaRetiro, cantidadRetiro);
                    break;
                case 6:
                    System.out.print("Ingrese el número de cuenta de origen: ");
                    String numeroCuentaOrigen = scanner.next();
                    System.out.print("Ingrese el número de cuenta de destino: ");
                    String numeroCuentaDestino = scanner.next();
                    System.out.print("Ingrese la cantidad a transferir: ");
                    double cantidadTransferencia = scanner.nextDouble();
                    controlador.realizarTransferencia(numeroCuentaOrigen, numeroCuentaDestino, cantidadTransferencia);
                    break;
                case 7:
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuentaConsulta = scanner.next();
                    double saldo = controlador.consultarSaldo(numeroCuentaConsulta);
                    System.out.println("El saldo de la cuenta es: " + saldo);
                    break;
                case 8:
                    System.out.println("Gracias por usar el banco. ¡Hasta luego!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }
}
