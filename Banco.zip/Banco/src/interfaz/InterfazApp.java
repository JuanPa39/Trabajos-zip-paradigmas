package interfaz;

import banco.Banco;
import cuentas.CuentaPlazoFijo;

public class InterfazApp {
    public static void main(String[] args) {
        Banco banco = new Banco();

        // Crear cuentas
        banco.crearCuentaAhorro("12345", 1000);
        banco.crearCuentaCorriente("67890", 2000, 500);
        banco.crearCuentaPlazoFijo("11223", 5000, 12, 5);

        // Realizar operaciones
        banco.realizarDeposito("12345", 200);
        banco.realizarRetiro("67890", 1500);
        banco.realizarTransferencia("12345", "67890", 100);

        // Obtener cuentas y mostrar saldos
        System.out.println("Saldo cuenta ahorro: " + banco.obtenerCuenta("12345").getSaldo());
        System.out.println("Saldo cuenta corriente: " + banco.obtenerCuenta("67890").getSaldo());

        // Intentar retirar de cuenta plazo fijo
        banco.realizarRetiro("11223", 1000);

        // Aplicar interés a cuenta plazo fijo
        CuentaPlazoFijo cuentaPlazoFijo = (CuentaPlazoFijo) banco.obtenerCuenta("11223");
        cuentaPlazoFijo.aplicarInteres();
        System.out.println("Saldo cuenta plazo fijo después de aplicar interés: " + cuentaPlazoFijo.getSaldo());
    }
}
