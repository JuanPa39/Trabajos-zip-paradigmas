package cuentas;

public class CuentaPlazoFijo extends Cuenta {
    private int plazo; // en meses
    private double interes; // porcentaje anual

    public CuentaPlazoFijo(String numeroCuenta, double saldoInicial, int plazo, double interes) {
        super(numeroCuenta, saldoInicial);
        this.plazo = plazo;
        this.interes = interes;
    }

    @Override
    public void depositar(double cantidad) {
        System.out.println("No se pueden realizar depósitos en una cuenta a plazo fijo.");
    }

    @Override
    public void retirar(double cantidad) {
        System.out.println("No se pueden realizar retiros antes del vencimiento del plazo.");
    }

    public void aplicarInteres() {
        saldo += saldo * (interes / 100) * (plazo / 12.0);
    }
}
