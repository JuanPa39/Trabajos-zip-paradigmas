package cuentas;

public abstract class Cuenta {
    protected String numeroCuenta;
    protected double saldo;

    public Cuenta(String numeroCuenta, double saldoInicial) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldoInicial;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public abstract void depositar(double cantidad);

    public abstract void retirar(double cantidad);

    public void transferir(Cuenta destino, double cantidad) {
        if (this.saldo >= cantidad) {
            this.retirar(cantidad);
            destino.depositar(cantidad);
        } else {
            System.out.println("Saldo insuficiente para la transferencia.");
        }
    }
}
