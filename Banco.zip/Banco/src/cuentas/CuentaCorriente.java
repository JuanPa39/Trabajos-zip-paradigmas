package cuentas;

public class CuentaCorriente extends Cuenta {
    private double limiteDescubierto;

    public CuentaCorriente(String numeroCuenta, double saldoInicial, double limiteDescubierto) {
        super(numeroCuenta, saldoInicial);
        this.limiteDescubierto = limiteDescubierto;
    }

    @Override
    public void depositar(double cantidad) {
        saldo += cantidad;
    }

    @Override
    public void retirar(double cantidad) {
        if (saldo + limiteDescubierto >= cantidad) {
            saldo -= cantidad;
        } else {
            System.out.println("Saldo insuficiente para el retiro.");
        }
    }
}
