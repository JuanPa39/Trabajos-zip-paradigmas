package controlador;

import banco.Banco;
import cuentas.Cuenta;

public class Controlador {
    private Banco banco;

    public Controlador() {
        banco = new Banco();
    }

    public void crearCuentaAhorro(String numeroCuenta, double saldoInicial) {
        banco.crearCuentaAhorro(numeroCuenta, saldoInicial);
    }

    public void crearCuentaCorriente(String numeroCuenta, double saldoInicial, double limiteDescubierto) {
        banco.crearCuentaCorriente(numeroCuenta, saldoInicial, limiteDescubierto);
    }

    public void crearCuentaPlazoFijo(String numeroCuenta, double saldoInicial, int plazo, double interes) {
        banco.crearCuentaPlazoFijo(numeroCuenta, saldoInicial, plazo, interes);
    }

    public void realizarDeposito(String numeroCuenta, double cantidad) {
        banco.realizarDeposito(numeroCuenta, cantidad);
    }

    public void realizarRetiro(String numeroCuenta, double cantidad) {
        banco.realizarRetiro(numeroCuenta, cantidad);
    }

    public void realizarTransferencia(String numeroCuentaOrigen, String numeroCuentaDestino, double cantidad) {
        banco.realizarTransferencia(numeroCuentaOrigen, numeroCuentaDestino, cantidad);
    }

    public double consultarSaldo(String numeroCuenta) {
        Cuenta cuenta = banco.obtenerCuenta(numeroCuenta);
        if (cuenta != null) {
            return cuenta.getSaldo();
        } else {
            System.out.println("Cuenta no encontrada.");
            return 0;
        }
    }
}
