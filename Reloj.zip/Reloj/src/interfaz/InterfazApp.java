/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfaz;

import java.util.Scanner;
import mundo.Reloj;

/**
 *
 * @author SG701-03
 */
public class InterfazApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Reloj relojito = new Reloj();
        relojito.actual();
        
        System.out.println("¿Desea cambiar la hora? \n 1.Si \n Cualquier otro número. No");
        int condicion = sc.nextInt();
        if(condicion == 1){
            System.out.println("Cambie la hora: ");
            relojito.setHora(sc.nextInt());
            System.out.println("Cambie los minutos: ");
            relojito.setMinutos(sc.nextInt());
            System.out.println("Cambie los segundos: ");
            relojito.setSegundos(sc.nextInt());
        }
        relojito.actual();
    }
    
}
