package controlador;

import interfaz.PanelDatos;
import mundo.Proceso;

public class Controlador {
    private Proceso proceso;
    private PanelDatos pnlDatos;

    public Controlador(int varA, int varB) {
        this.proceso = new Proceso(varA, varB);
    }

    
    
    public Controlador(Proceso proceso, PanelDatos pnlDatos) {
        this.proceso = proceso;
        this.pnlDatos = pnlDatos;
    }
    

    public void intercambiarValores() {
        proceso.ejecutar();
    }

    public int getVarA() {
        return proceso.getVarA();
    }

    public int getVarB() {
        return proceso.getVarB();
    }

    public void setProceso(Proceso proceso) {
        this.proceso = proceso;
    }
    
    
}
