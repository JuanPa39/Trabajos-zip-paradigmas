package interfaz;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Color;
import controlador.Controlador;

public class PanelDatos extends JPanel {

    private Controlador controlador;
    private JLabel labelVarA;
    private JLabel labelVarB;

    public PanelDatos(Controlador controlador) {
        this.controlador = controlador;

        JPanel pnlDatos = new JPanel();
        pnlDatos.setLayout(new GridBagLayout());
        pnlDatos.setBackground(new Color(220, 220, 220)); 

        JLabel labelAtributoA = new JLabel("Atributo A");
        labelVarA = new JLabel(Integer.toString(controlador.getVarA()));
        JPanel panelValorA = new JPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        
        panelValorA.setBackground(Color.WHITE);
        panelValorA.add(labelVarA);
        gbc.gridy++;
        pnlDatos.add(labelAtributoA, gbc);
        gbc.gridy++;
        pnlDatos.add(panelValorA, gbc);

        JLabel labelAtributoB = new JLabel("Atributo B");
        labelVarB = new JLabel(Integer.toString(controlador.getVarB()));
        JPanel panelValorB = new JPanel();
        panelValorB.setBackground(Color.WHITE);
        panelValorB.add(labelVarB);
        gbc.gridy++;
        pnlDatos.add(labelAtributoB, gbc);
        gbc.gridy++;
        pnlDatos.add(panelValorB, gbc);

        JButton botonIntercambiar = new JButton("Ejecutar");
        botonIntercambiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.intercambiarValores();
                actualizarValores();
            }
        });
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST;
        pnlDatos.add(botonIntercambiar, gbc);

        setLayout(new GridBagLayout());
        GridBagConstraints Panel = new GridBagConstraints();
        Panel.ipadx = 150;
        Panel.ipady = 60;
        add(pnlDatos, Panel);
    }

    public void actualizarValores() {
        labelVarA.setText(Integer.toString(controlador.getVarA()));
        labelVarB.setText(Integer.toString(controlador.getVarB()));
    }
}
