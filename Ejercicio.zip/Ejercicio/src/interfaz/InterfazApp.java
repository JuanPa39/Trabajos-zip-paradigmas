package interfaz;

import javax.swing.JFrame;
import controlador.Controlador;

public class InterfazApp {
    private PanelDatos pnlDatos;
    private Controlador crtl;

    public InterfazApp(PanelDatos pnlDatos, Controlador crtl) {
        this.crtl = crtl;
        this.pnlDatos = pnlDatos;
    }
    
    
    public static void main(String[] args) {
        Controlador crtl = new Controlador(1000, 2000);
        PanelDatos pnlDatos = new PanelDatos(crtl);

        JFrame frame = new JFrame("Ejercicio 1.0:");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(pnlDatos);
        frame.pack();
        frame.setVisible(true);
    }
}

