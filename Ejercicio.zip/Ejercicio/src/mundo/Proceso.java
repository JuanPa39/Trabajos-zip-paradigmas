package mundo;

public class Proceso {
    private int varA;
    private int varB;

    public Proceso(int varA, int varB) {
        this.varA = varA;
        this.varB = varB;
    }

    public void ejecutar() {
        int aux = varA;
        varA = varB;
        varB = aux;
    }
    
    public int getVarA() {
        return varA;
    }

    public int getVarB() {
        return varB;
    }

    public void setVarA(int varA) {
        this.varA = varA;
    }

    public void setVarB(int varB) {
        this.varB = varB;
    }
}
