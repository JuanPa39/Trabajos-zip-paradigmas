package interfaz;

import mundo.Pirinola;

public class InterfazApp {

    public static void main(String[] args) {
      Pirinola pirinola = new Pirinola();
        
        pirinola.girar();
        System.out.println(pirinola.caraSeleccionada);
    }
}
