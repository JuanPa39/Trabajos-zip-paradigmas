package mundo;

public class Pirinola {

    private String cara1, cara2, cara3, cara4, cara5, cara6;
    public String caraSeleccionada;

    public Pirinola() {
        this.cara1 = "Toma todo";
        this.cara2 = "Todos ponen";
        this.cara3 = "Pon 1";
        this.cara4 = "Pon 2";
        this.cara5 = "Toma 1";
        this.cara6 = "Toma 2";
        this.caraSeleccionada = null;

    }

    public void setCara1(String cara1) {
        this.cara1 = cara1;
    }

    public void setCara2(String cara2) {
        this.cara2 = cara2;
    }

    public void setCara3(String cara3) {
        this.cara3 = cara3;
    }

    public void setCara4(String cara4) {
        this.cara4 = cara4;
    }

    public void setCara5(String cara5) {
        this.cara5 = cara5;
    }

    public void setCara6(String caara6) {
        this.cara6 = caara6;
    }

    public void setCaraSeleccionada(String caraSeleccionada) {
        this.caraSeleccionada = caraSeleccionada;
    }
    

    
    
    

    public void girar() {
        int caraAleatoria;
        int giros = (int) (Math.random() * 100) + 1;
        for (int i = 0; i < giros; i++) {
            caraAleatoria = (int) (Math.random() * 6) + 1;

            switch (caraAleatoria) {
                case 1:
                    this.caraSeleccionada = cara1;
                    break;
                case 2:
                    this.caraSeleccionada = cara2;
                    break;
                case 3:
                    this.caraSeleccionada = cara3;
                    break;
                case 4:
                    this.caraSeleccionada = cara4;
                    break;
                case 5:
                    this.caraSeleccionada = cara5;
                    break;
                case 6:
                    this.caraSeleccionada = cara6;
                    break;

            }
        }
    }

}
