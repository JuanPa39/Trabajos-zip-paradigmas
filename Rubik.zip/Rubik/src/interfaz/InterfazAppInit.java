
package interfaz;

import java.awt.Color;
import javax.swing.JFrame;

/**
 *
 * @author SG701-03
 */
public class InterfazAppInit {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InterfazApp panel = new InterfazApp();
        panel.setVisible(true);
        panel.setResizable(false);
        panel.setLocationRelativeTo(panel);
        panel.setTitle("Cubito");
        panel.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
    }
    
}
