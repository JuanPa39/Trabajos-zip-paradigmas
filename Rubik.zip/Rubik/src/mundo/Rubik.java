package mundo;

public class Rubik {

    private Cubo rubik[][][];

    public Rubik() {
        rubik = new Cubo[2][2][2]; 

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 2; k++) {
                    rubik[i][j][k] = new Cubo();
                }
            }
        }
    }

    public Cubo[][][] getRubik() {
        return rubik;
    }
    
    public void giroDiscoX(boolean giroDerecha) {
        
        if (giroDerecha) {
            Cubo temp = rubik[0][0][0];
            rubik[0][0][0] = rubik[0][1][0];
            rubik[0][1][0] = rubik[0][1][1];
            rubik[0][1][1] = rubik[0][0][1];
            rubik[0][0][1] = temp;
        } else {
            Cubo temp = rubik[0][0][0];
            rubik[0][0][0] = rubik[0][0][1];
            rubik[0][0][1] = rubik[0][1][1];
            rubik[0][1][1] = rubik[0][1][0];
            rubik[0][1][0] = temp;
        }
    }

    public void giroDiscoY(boolean giroDerecha) {
        
        if (giroDerecha) {
            Cubo temp = rubik[0][0][0];
            rubik[0][0][0] = rubik[1][0][0];
            rubik[1][0][0] = rubik[1][0][1];
            rubik[1][0][1] = rubik[0][0][1];
            rubik[0][0][1] = temp;
        } else {
            Cubo temp = rubik[0][0][0];
            rubik[0][0][0] = rubik[0][0][1];
            rubik[0][0][1] = rubik[1][0][1];
            rubik[1][0][1] = rubik[1][0][0];
            rubik[1][0][0] = temp;
        }
    }

    public void giroDiscoZ(boolean giroDerecha) {
        
        if (giroDerecha) {
            Cubo temp = rubik[0][0][0];
            rubik[0][0][0] = rubik[0][0][1];
            rubik[0][0][1] = rubik[1][0][1];
            rubik[1][0][1] = rubik[1][0][0];
            rubik[1][0][0] = temp;
        } else {
            Cubo temp = rubik[0][0][0];
            rubik[0][0][0] = rubik[1][0][0];
            rubik[1][0][0] = rubik[1][0][1];
            rubik[1][0][1] = rubik[0][0][1];
            rubik[0][0][1] = temp;
        }
    }
}

