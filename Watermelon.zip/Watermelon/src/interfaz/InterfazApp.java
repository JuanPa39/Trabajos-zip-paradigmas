package interfaz;

import java.util.Scanner;
class Watermelon {

    private int w;

    public Watermelon() {
    }

    public int getW() {
        return w;
    }

    public void setW(int w) {
        if (w >= 1 && w <= 100) {
            this.w = w;
        }

    }

    public void calcular() {
        if (2 < w && w % 2 == 0) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}
public class InterfazApp {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        Watermelon water = new Watermelon();
        
        water.setW(sc.nextInt());
        water.calcular();
       
        
    }
    
}
