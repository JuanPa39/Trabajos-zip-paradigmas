package interfaz;

import mundo.Persona;

public class InterfazApp {

    public static void main(String[] args) {
        Persona persona = new Persona("carla",80,0);
        
        System.out.println(persona.getNombre() + "\n" + persona.getEdad());
        persona.getSexo();
        persona.nivel();
        persona.setSexo(1);
        System.out.println(persona.getNombre() + "\n" + persona.getEdad());
        persona.getSexo();
        persona.nivel();
    }
    
}
