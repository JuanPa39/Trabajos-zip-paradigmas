package mundo;

public class Persona {

    //Atributos
    private String nombre;
    private int edad, sexo;

    //Constructores
    public Persona() {
    }

    public Persona(String nombre, int edad, int sexo) {
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = sexo;
    }

    //metodos get y set
    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getSexo() {
        if (sexo == 0) {
            System.out.println("Mujer");
            return sexo;
        } else if (sexo == 1) {
            System.out.println("Hombre");
            return sexo;
        } else {
            return sexo;
        }
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setSexo(int sexo) {
        this.sexo = sexo;
    }

    //Metodo funcional "nivel" para dividir por edades
    public void nivel() {
        if (edad < 10) {
            System.out.println("Infante");
        }
        if (edad >= 10 && edad < 18) {
            System.out.println("Adolescente");
        }
        if (edad >= 18 && edad <= 60) {
            System.out.println("Adulto");
        }
        if (edad > 60) {
            System.out.println("Adulto mayor");
        }
    }

}
