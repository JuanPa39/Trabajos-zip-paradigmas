package controlador;

import mundo.Figura;
import java.util.ArrayList;
import java.util.List;

public class Controlador {
    private List<Figura> figuras;

    // Constructor
    public Controlador() {
        this.figuras = new ArrayList<>();
    }

    // Método para agregar una figura a la lista
    public void agregarFigura(Figura figura) {
        figuras.add(figura);
    }

    // Método para mostrar el área y el perímetro de todas las figuras
    public void mostrarFiguras() {
        for (Figura figura : figuras) {
            System.out.println("Figura: " + figura.getClass().getSimpleName());
            System.out.println("  Área: " + figura.area());
            System.out.println("  Perímetro: " + figura.perimetro());
        }
    }
}

