/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfaz;

import controlador.Controlador;
import mundo.Circulo;
import mundo.Cuadrado;
import mundo.Triangulo;

public class InterfazApp {
    public static void main(String[] args) {
        // Crear instancia del controlador
        Controlador controlador = new Controlador();

        // Crear instancias de cada figura y agregarlas al controlador
        controlador.agregarFigura(new Circulo(5));
        controlador.agregarFigura(new Cuadrado(4));
        controlador.agregarFigura(new Triangulo(3));

        // Mostrar el área y el perímetro de todas las figuras
        controlador.mostrarFiguras();
    }
}