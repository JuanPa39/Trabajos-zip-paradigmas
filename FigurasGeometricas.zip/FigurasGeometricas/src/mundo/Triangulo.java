package mundo;

public class Triangulo extends Figura {
    private double lado;

    // Constructor
    public Triangulo(double lado) {
        this.lado = lado;
    }

    // Implementación del método area para un triángulo equilátero
    @Override
    public double area() {
        return (Math.sqrt(3) / 4) * Math.pow(lado, 2);
    }

    // Implementación del método perimetro para un triángulo equilátero
    @Override
    public double perimetro() {
        return 3 * lado;
    }
}


