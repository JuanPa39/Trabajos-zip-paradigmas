package mundo;

public class Circulo extends Figura {
    private double radio;

    // Constructor
    public Circulo(double radio) {
        this.radio = radio;
    }

    // Implementación del método area para un círculo
    @Override
    public double area() {
        return Math.PI * Math.pow(radio, 2);
    }

    // Implementación del método perimetro para un círculo
    @Override
    public double perimetro() {
        return 2 * Math.PI * radio;
    }
}

