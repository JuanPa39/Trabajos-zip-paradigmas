package mundo;

public abstract class Figura {
    // Métodos abstractos para calcular el área y el perímetro
    public abstract double area();
    public abstract double perimetro();
}
