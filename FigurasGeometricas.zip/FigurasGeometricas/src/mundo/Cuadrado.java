package mundo;

public class Cuadrado extends Figura {
    private double lado;

    // Constructor
    public Cuadrado(double lado) {
        this.lado = lado;
    }

    // Implementación del método area para un cuadrado
    @Override
    public double area() {
        return Math.pow(lado, 2);
    }

    // Implementación del método perimetro para un cuadrado
    @Override
    public double perimetro() {
        return 4 * lado;
    }
}
