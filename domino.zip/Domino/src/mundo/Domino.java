package mundo;

public class Domino {

    private int esquinaA, esquinaB;

    public Domino() {
    }

    public Domino(int esquinaA, int esquinaB) {
        this.esquinaA = esquinaA;
        this.esquinaB = esquinaB;
    }

    public int getEsquinaA() {
        return esquinaA;
    }

    public int getEsquinaB() {
        return esquinaB;
    }

    public void setEsquinaA(int esquinaA) {
        this.esquinaA = esquinaA;
        if (esquinaA >= 0 && esquinaA <= 6) {
            System.out.println("Esquina esta dentro del rango");
        }
    }   

    public void setEsquinaB(int esquinaB) {
        this.esquinaB = esquinaB;
        if (esquinaB >= 0 && esquinaB <= 6) {
            System.out.println("Esquina esta dentro del rango");
        }
    }
    public void emparejar(Domino obj){
        if(esquinaA == obj.esquinaA || esquinaA == obj.esquinaB || esquinaB == obj.esquinaA || esquinaB == obj.esquinaB){
            System.out.println("True");
        }
        else{
            System.out.println("False");
        }
    }

}
