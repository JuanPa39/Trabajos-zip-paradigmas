package interfaz;

import mundo.Domino;

public class InterfazApp {

    public static void main(String[] args) {

        Domino obj1 = new Domino();
        Domino obj2 = new Domino();

        //asignacion de valores
        
        obj1.setEsquinaA(6);
        obj1.setEsquinaB(1);
        
        obj2.setEsquinaA(1);
        obj2.setEsquinaB(0);
        
        System.out.println("Obj1= " + obj1.getEsquinaA() + " " + obj1.getEsquinaB());
        System.out.println("Obj2= " + obj2.getEsquinaA() + " " + obj2.getEsquinaB());
        obj1.emparejar(obj2);
        
        //Cambiar los valores para que no se pueda emparejar
        
        obj2.setEsquinaA(5);
        
        System.out.println("Obj1= " + obj1.getEsquinaA() + " " + obj1.getEsquinaB());
        System.out.println("Obj2= " + obj2.getEsquinaA() + " " + obj2.getEsquinaB());
        
        obj1.emparejar(obj2);
        
    }

}
