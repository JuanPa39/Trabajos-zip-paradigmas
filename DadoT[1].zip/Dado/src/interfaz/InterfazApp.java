package interfaz;

import java.util.Scanner;
import mundo.Dado;

public class InterfazApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n;

        Dado dado = new Dado();
        
        
        do{
        System.out.println("¿De que forma desea girar en dado?");
        System.out.println("1.Giro horizontal \n 2.Giro Vertical \n 3.Giro transversal \n 4.Salir");
        n = sc.nextInt();

        switch (n) {
            case 1:
                dado.giroEjeX();
                dado.imprimirEstado();
                break;
            case 2:
                dado.giroEjeY();
                dado.imprimirEstado();
                break;
            case 3:
                dado.giroEjeZ();
                dado.imprimirEstado();
                break;
        }
        }while(n!=4);
    }
}
