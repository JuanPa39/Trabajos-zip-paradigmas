package mundo;

import javax.swing.JTextArea;

public class Proceso {
    private int a;
    private int b;

    public Proceso() {
    }
    
    public JTextArea ejecutar(int n) {
        a = 0;
        b = 1;
        StringBuilder sb = new StringBuilder();
        sb.append("Serie de Fibbonacci").append(n).append(" números:\n");
        for (int i = 0; i < n; i++) {
            sb.append(a).append("\n");
            int temp= a+b;
            a = b;
            b = temp;
        }
        JTextArea txt = new JTextArea();
        txt.setText(sb.toString());
        return txt;
    }
    
}

