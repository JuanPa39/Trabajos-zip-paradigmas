package mundo;

public class Proceso {
    private int varA;
    private int varB;
    private int varC;

    public Proceso(int varA, int varB, int varC) {
        this.varA = varA;
        this.varB = varB;
        this.varC = varC;
    }

    public void ejecutar() {
        int aux;
        if(varA >= varB){
            if (varC >= varA){aux = varA; this.varA = varC;this.varC = varB;this.varB = aux;}
        }
        if(varA >= varC){
            if (varC >= varB){aux=varB; this.varB = varC;this.varC = aux;}
            else if(varB >= varA){aux=varA;this.varA = varB;this.varB = aux;}
        }
        if(varB >= varC){
            if (varC >= varA){aux=varA;this.varA = varB;this.varB = varC;this.varC = aux;}
        }
        if(varC >= varB){
            if (varB >= varA){aux=varA;this.varA = varC;this.varC = aux;}
        }
    }
    
    public int getVarA() {
        return varA;
    }

    public int getVarB() {
        return varB;
    }

    public int getVarC() {
        return varC;
    }

    public void setVarA(int varA) {
        this.varA = varA;
    }

    public void setVarB(int varB) {
        this.varB = varB;
    }

    public void setVarC(int varC) {
        this.varC = varC;
    }
}
