package controlador;

import interfaz.PanelDatos;
import mundo.Proceso;

public class Controlador {
    private Proceso proceso;
    private PanelDatos pnlDatos;

    public Controlador(int varA, int varB, int varC) {
        this.proceso = new Proceso(varA, varB, varC);
    }

    public void intercambiarValores() {
        proceso.ejecutar();
    }

    public int getVarA() {
        return proceso.getVarA();
    }

    public int getVarB() {
        return proceso.getVarB();
    }
    public int getVarC() {
        return proceso.getVarC();
    }
    public void setVarA(int varA){
        this.proceso.setVarA(varA);
    }
    
    public void setVarB(int varB){
        this.proceso.setVarB(varB);
    }
    public void setVarC(int varC){
        this.proceso.setVarC(varC);
    }
    public void setProceso(Proceso proceso) {
        this.proceso = proceso;
    }
    
    
}
