package controlador;

import interfaz.PanelDatos;
import javax.swing.JTextArea;
import mundo.Proceso;

public class Controlador {
    private Proceso proceso;
    private PanelDatos pnlDatos;

    public Controlador() {
        this.proceso = new Proceso();
    }

    public JTextArea numeroFibbonacci() {
        return proceso.ejecutar(20);
    }
    public void setProceso(Proceso proceso) {
        this.proceso = proceso;
    }
    
    
}
