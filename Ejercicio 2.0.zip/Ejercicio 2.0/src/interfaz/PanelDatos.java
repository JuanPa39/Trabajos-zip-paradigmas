package interfaz;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Color;
import controlador.Controlador;
import java.awt.Dimension;
import javax.swing.JTextField;

public class PanelDatos extends JPanel {

    private Controlador controlador;
    private JTextField labelVarA;
    private JTextField labelVarB;
    private JTextField labelVarC;

    public PanelDatos(Controlador controlador) {
        this.controlador = controlador;

        JPanel pnlDatos = new JPanel();
        pnlDatos.setLayout(new GridBagLayout());
        pnlDatos.setBackground(new Color(220, 220, 220));

        JLabel labelAtributoA = new JLabel("Atributo A");
        labelVarA = new JTextField(Integer.toString(controlador.getVarA()));
        labelVarA.setPreferredSize(new Dimension(200, 30));
        JPanel panelValorA = new JPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        panelValorA.setBackground(Color.WHITE);
        panelValorA.add(labelVarA);
        gbc.gridy++;
        pnlDatos.add(labelAtributoA, gbc);
        gbc.gridy++;
        pnlDatos.add(panelValorA, gbc);

        JLabel labelAtributoB = new JLabel("Atributo B");
        labelVarB = new JTextField(Integer.toString(controlador.getVarB()));
        labelVarB.setPreferredSize(new Dimension(200, 30));
        JPanel panelValorB = new JPanel();
        panelValorB.setBackground(Color.WHITE);
        panelValorB.add(labelVarB);
        gbc.gridy++;
        pnlDatos.add(labelAtributoB, gbc);
        gbc.gridy++;
        pnlDatos.add(panelValorB, gbc);
        
        
        JLabel labelAtributoC = new JLabel("Atributo C");
        labelVarC = new JTextField(Integer.toString(controlador.getVarC()));
        labelVarC.setPreferredSize(new Dimension(200, 30));
        JPanel panelValorC = new JPanel();
        panelValorC.setBackground(Color.WHITE);
        panelValorC.add(labelVarC);
        gbc.gridy++;
        pnlDatos.add(labelAtributoC, gbc);
        gbc.gridy++;
        pnlDatos.add(panelValorC, gbc);

        JButton botonIntercambiar = new JButton("Ejecutar");
        botonIntercambiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.setVarA(Integer.parseInt(labelVarA.getText()));
                controlador.setVarB(Integer.parseInt(labelVarB.getText()));
                controlador.setVarC(Integer.parseInt(labelVarC.getText()));
                controlador.intercambiarValores();
                actualizarValores();
            }
        });
        
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST;
        pnlDatos.add(botonIntercambiar, gbc);

        setLayout(new GridBagLayout());
        GridBagConstraints Panel = new GridBagConstraints();
        Panel.ipadx = 150;
        Panel.ipady = 90;
        add(pnlDatos, Panel);
    }

    public void actualizarValores() {
        labelVarA.setText(Integer.toString(controlador.getVarA()));
        labelVarB.setText(Integer.toString(controlador.getVarB()));
        labelVarC.setText(Integer.toString(controlador.getVarC()));
    }
}
