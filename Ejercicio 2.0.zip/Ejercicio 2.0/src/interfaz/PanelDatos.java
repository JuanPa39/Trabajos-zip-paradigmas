package interfaz;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Color;
import controlador.Controlador;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class PanelDatos extends JPanel {

    private Controlador controlador;
    private JTextArea textArea = new JTextArea();

    public PanelDatos(Controlador controlador) {
        this.controlador = controlador;

        JPanel pnlDatos = new JPanel();
        pnlDatos.setLayout(new GridBagLayout());
        pnlDatos.setBackground(new Color(220, 220, 220));
        
        JTextArea textArea = new JTextArea("hi");
        textArea.setFont(new Font("Serif", Font.ITALIC, 16));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JPanel panelTextArea = new JPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        panelTextArea.setBackground(Color.WHITE);
        panelTextArea.add(textArea);
        gbc.gridy++;
        pnlDatos.add(panelTextArea, gbc);
        gbc.gridy++;
        pnlDatos.add(panelTextArea, gbc);

        JButton botonIntercambiar = new JButton("Ejecutar");
        botonIntercambiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                imprimirDatos();
            }
        });

        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST;
        pnlDatos.add(botonIntercambiar, gbc);

        setLayout(new GridBagLayout());
        GridBagConstraints Panel = new GridBagConstraints();
        Panel.ipadx = 150;
        Panel.ipady = 90;
        add(pnlDatos, Panel);
    }
    public void imprimirDatos(){
        controlador.numeroFibbonacci();
        repaint();
        revalidate();
    }

}
