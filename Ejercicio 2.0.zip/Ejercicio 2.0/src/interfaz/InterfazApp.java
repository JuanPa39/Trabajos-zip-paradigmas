package interfaz;

import javax.swing.JFrame;
import controlador.Controlador;

public class InterfazApp {
    private PanelDatos pnlDatos;
    private Controlador crtl;

    public InterfazApp(Controlador crtl,PanelDatos pnlDatos) {
        this.crtl = crtl;
        this.pnlDatos = pnlDatos;
        JFrame frame = new JFrame("Ejercicio 3.0:");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(pnlDatos);
        frame.pack();
        frame.setVisible(true);

    }
    
    
    public static void main(String[] args) {
        Controlador crtl = new Controlador();
        PanelDatos pnlDatos = new PanelDatos(crtl);
        InterfazApp interfaz = new InterfazApp(crtl,pnlDatos);
        
    }
}

